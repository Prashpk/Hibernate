package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


public class MainApp2 {

	public static void main(String[] args) {
				MyLaptop lob=new MyLaptop();
				lob.setLid(4);
				lob.setLname("Lenovo");
				lob.setLprice(80000);
				
		        Configuration conn=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(MyLaptop.class);	
//		        ServiceRegistry reg=new ServiceRegistryBuilder().applySettings(conn.getProperties()).buildServiceRegistry();
		        SessionFactory sf=conn.buildSessionFactory();
		        Session sess=sf.openSession();
		        Transaction tx=sess.beginTransaction();
		        
		        sess.save(lob);
		        tx.commit();  		
			}
}