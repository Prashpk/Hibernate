package com.edu;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Actors{
@Id
private int Aid;
private String Aname;
public int getAid() {
	return Aid;
}
public void setAid(int aid) {
	Aid = aid;
}
public String getAname() {
	return Aname;
}
public void setAname(String aname) {
	Aname = aname;
}
@Override
public String toString() {
	return "Actors [Aid=" + Aid + ", Aname=" + Aname + "]";
}


}
