package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainApp {

	public static void main(String[] args) {

		        Configuration conn=new Configuration().configure().addAnnotatedClass(EmployeeHql.class);	
		        ServiceRegistry reg=new ServiceRegistryBuilder().applySettings(conn.getProperties()).buildServiceRegistry();
		        SessionFactory sf=conn.buildSessionFactory(reg);
		        Session sess=sf.openSession();
		        Transaction tx=sess.beginTransaction();
		        EmployeeHql e1 = new EmployeeHql(1,"leela",23456,"Bangalore",100);
		        sess.save(e1);
		        EmployeeHql e2 = new EmployeeHql(2,"prash",23457,"Mangalore",200);
		        sess.save(e2);
		        EmployeeHql e3 = new EmployeeHql(3,"Rocky",54678,"Mysore",300);
		        sess.save(e3);
		        EmployeeHql e4 = new EmployeeHql(4,"Asha",765543,"Rajasthan",400);
		        sess.save(e4);
		
		        tx.commit();  		
			}
}